﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3.Intersection_Of_Circles
{
    public class Circle
    {
        public int Center { get; set; }
        public int Radius { get; set; }
    }
}
